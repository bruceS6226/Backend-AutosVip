const { Sequelize } = require("sequelize");
const { Repuesto, FotoRepuesto } = require("../../models/repuestos/repuesto");
const XLSX = require('xlsx');
const { crearCategoriasDentroMarcasVehiculo } = require("../marcas_vehiculo/categorias.dentro.marcas.vehiculo.controller");

const obtenerRepuestos = async (req, res) => {
    try {
        const listaRepuestos = await Repuesto.findAll();
        res.status(202).json(listaRepuestos)
    } catch (error) {
        res.status(404).json({
            msg: 'Ha ocurrido un error al intentar obtener repuestos',
            error: error
        })
    }
}

const obtenerPrimeraFoto = async (req, res) => {
    try {
        const { id_repuesto } = req.params;
        if (id_repuesto) {
            const primeraImagen = await FotoRepuesto.findOne({
                where: { id_repuesto: id_repuesto }
            })
            if (primeraImagen) {
                res.status(202).json({
                    msg: 'Exito',
                    foto: primeraImagen.foto
                })
            } else {
                res.status(404).json({ msg: 'El repuesto no tiene fotos' })
            }
        } else {
            res.status(404).json({ msg: 'El id del repuesto es invalido' })
        }
    } catch (error) {
        res.status(404).json({
            msg: 'Ha ocurrido un error al intentar obtener repuestos',
            error: error
        })
    }
}

const obtenerFotos = async (req, res) => {
    try {
        const { id_repuesto } = req.params;
        if (id_repuesto) {
            const fotos = await FotoRepuesto.findAll({
                where: { id_repuesto: id_repuesto }
            })
            if (fotos) {
                res.status(202).json({
                    msg: 'Exito',
                    fotos: fotos
                })
            } else {
                res.status(404).json({ msg: 'El repuesto no tiene fotos' })
            }
        } else {
            res.status(404).json({ msg: 'El id del repuesto es invalido' })
        }
    } catch (error) {
        res.status(404).json({
            msg: 'Ha ocurrido un error al intentar obtener repuestos',
            error: error
        })
    }
}
const obtenerRepuesto = async (req, res) => {
    try {
        const { id_repuesto } = req.params;
        if (id_repuesto) {
            const repuestoExistente = await Repuesto.findOne({
                where: { id_repuesto: id_repuesto }
            })
            if (repuestoExistente) {
                res.status(202).json({
                    msg: 'Exito',
                    repuesto: repuestoExistente
                })
            } else {
                res.status(404).json({ msg: 'El repuesto no existe' })
            }
        } else {
            res.status(404).json({ msg: 'El id del repuesto es invalido' })
        }
    } catch (error) {
        res.status(404).json({
            msg: 'Ha ocurrido un error al intentar obtener repuestos',
            error: error
        })
    }
}
const buscarRepuestos = async (req, res) => {
    try {
        const { textoBuscar } = req.params;
        if (textoBuscar) {
            var condicionesDeBusqueda;
            const atributos = Object.keys(Repuesto.rawAttributes);
            const palabras = textoBuscar.split(' ').filter(palabra => palabra.trim() !== '');
            condicionesDeBusqueda = palabras.map(palabra => ({
                [Sequelize.Op.or]: atributos.map(atributo => ({
                    [atributo]: { [Sequelize.Op.like]: `%${palabra}%` }
                }))
            }));
            const repuestosEncontrados = await Repuesto.findAll({
                where: {
                    [Sequelize.Op.and]: condicionesDeBusqueda
                }
            });
            const repuestosEncontradosPorPalabras = await Repuesto.findAll({
                where: {
                    [Sequelize.Op.or]: condicionesDeBusqueda
                }
            });
            if (repuestosEncontrados && repuestosEncontradosPorPalabras) {
                res.status(202).json({
                    repuestos: repuestosEncontrados,
                    repuestosSugeridos: repuestosEncontradosPorPalabras
                })
            } else {
                if (!repuestosEncontrados && repuestosEncontradosPorPalabras) {
                    res.status(202).json({
                        repuestos: [],
                        repuestosSugeridos: repuestosEncontradosPorPalabras
                    })
                }
                if (!repuestosEncontrados && !repuestosEncontradosPorPalabras) {
                    res.status(202).json({
                        repuestos: [],
                        repuestosSugeridos: []
                    })
                }
            }
        } else {
            const todosRepuestos = await Repuesto.findAll();
            res.status(202).json({
                repuestos: todosRepuestos,
                repuestosSugeridos: [],
            });
        }
    } catch (error) {
        res.status(500).json({
            msg: 'Ha ocurrido un error al intentar buscar repuestos',
            error: error
        });
    }


}

const crearRepuesto0 = async (req, res) => {
    try {
        const { id_repuesto, nombre_repuesto, precio_PVP, cantidad_inventario, marca_vehiculo } = req.body;
        console.log(typeof (id_repuesto), typeof (precio_PVP), typeof (cantidad_inventario))
        const nuevoRepuesto = await Repuesto.create({
            id_repuesto, nombre_repuesto, precio_PVP, cantidad_inventario
        })
        console.log(req.body)
        if (marca_vehiculo) {
            //await crearCategoriasDentroMarcasVehiculo(req, res);
        }
        res.status(202).json(nuevoRepuesto)
    } catch (error) {
        res.status(404).json({
            msg: 'Ha ocurrido un error al intentar crear repuestos',
            error: error
        })
    }
}
function leerExcel(ruta) {
    const archivo = XLSX.readFile(ruta);
    const sheetsArchivo = archivo.SheetNames;
    const hojaRepuestos = sheetsArchivo[0]
    const datos = XLSX.utils.sheet_to_json(archivo.Sheets[hojaRepuestos])
    return datos;
}
const crearRepuesto = async (req, res) => {
    try {
        datosRepuestos = leerExcel('./uploads/repuestos.xlsx')
        if (datosRepuestos) {
            for (const dato of datosRepuestos) {
                const repuestoExistente = await Repuesto.findByPk(dato.id_repuesto)
                if (!repuestoExistente) {
                    await Repuesto.create({
                        id_repuesto: dato.id_repuesto,
                        nombre_repuesto: dato.nombre_repuesto,
                        precio_PVP: dato.precio_PVP,
                        cantidad_inventario: dato.cantidad_inventario
                    })
                    if (dato.marca_vehiculo) {
                        await crearCategoriasDentroMarcasVehiculo(dato.id_repuesto, dato.marca_vehiculo);
                    }
                }
            }
            res.status(202).json('Exito')
        } else {

        }
    } catch (error) {
        console.error("Error al crear el repuesto:", error);
        throw error;
    }
}
module.exports = { obtenerRepuestos, obtenerPrimeraFoto, obtenerRepuesto, obtenerFotos, buscarRepuestos, crearRepuesto }