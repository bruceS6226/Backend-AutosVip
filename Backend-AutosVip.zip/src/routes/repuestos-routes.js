const {Router} = require('express');
const { obtenerRepuestos, obtenerRepuesto, buscarRepuestos, obtenerPrimeraFoto, obtenerFotos, crearRepuesto } = require('../controllers/repuestos/repuestos.controller');
const { obtenerCategoriasDentroMarcasVehiculo } = require('../controllers/marcas_vehiculo/categorias.dentro.marcas.vehiculo.controller');
const { obtenerRepuestosPorCategoriaDentroMarcasVehiculo, obtenerRepuestosCategoriasDentroMarcasVehiculo } = require('../controllers/marcas_vehiculo/repuestos.categorias.marcas.controller');
const { obtenerRelacionesMarcasVehiculos } = require('../controllers/marcas_vehiculo/relacion.marcas.vehiculos.controller');
const { obtenerRelacionesSistemasVehiculos } = require('../controllers/sistemas_vehiculo/relacion.sistemas.vehiculos.controller');
const { obtenerCategoriasDentroSistemasVehiculo } = require('../controllers/sistemas_vehiculo/categorias.dentro.sistemas.vehiculo.controller');
const { obtenerRepuestosCategoriasDentroSistemasVehiculo, obtenerRepuestosPorCategoriaDentroSistemasVehiculo } = require('../controllers/sistemas_vehiculo/repuestos.categorias.sistemas.controller');


const router = Router();


router.get('/repuestos', obtenerRepuestos)
router.get('/repuesto/:id_repuesto', obtenerRepuesto)
router.get('/buscar/:textoBuscar?',buscarRepuestos)
//router.post('/crear-repuesto', crearRepuesto)
router.patch('/guardar-repuestos-excel', crearRepuesto)

router.get('/categorias_dentro_marcas_vehiculo', obtenerCategoriasDentroMarcasVehiculo)
router.get('/repuestos-categorias-dentro-marcas-vehiculo', obtenerRepuestosCategoriasDentroMarcasVehiculo)
router.get('/repuestos-por-categoria-dentro-marcas-vehiculo/*', obtenerRepuestosPorCategoriaDentroMarcasVehiculo)
router.get('/relaciones-marcas-vehiculo', obtenerRelacionesMarcasVehiculos)

router.get('/categorias_dentro_sistemas_vehiculo', obtenerCategoriasDentroSistemasVehiculo)
router.get('/repuestos-categorias-dentro-sistemas-vehiculo', obtenerRepuestosCategoriasDentroSistemasVehiculo)
router.get('/repuestos-por-categoria-dentro-sistemas-vehiculo/*', obtenerRepuestosPorCategoriaDentroSistemasVehiculo)
router.get('/relaciones-sistemas-vehiculo', obtenerRelacionesSistemasVehiculos)

router.get('/primera-foto/:id_repuesto', obtenerPrimeraFoto)
router.get('/fotos/:id_repuesto', obtenerFotos)

module.exports = router;
